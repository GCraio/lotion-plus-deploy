# add your delete-note function here
def handler(event, context):
    print("Hello, Lambda!")